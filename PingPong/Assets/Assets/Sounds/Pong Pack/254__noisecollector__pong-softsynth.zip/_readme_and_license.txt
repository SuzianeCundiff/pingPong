Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - NoiseCollector ( https://freesound.org/people/NoiseCollector/ )

You can find this pack online at: https://freesound.org/people/NoiseCollector/packs/254/

License details
---------------

Attribution: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 4391__NoiseCollector__pongblipF_5.wav
    * url: https://freesound.org/s/4391/
    * license: Attribution
  * 4390__NoiseCollector__pongblipF_4.wav
    * url: https://freesound.org/s/4390/
    * license: Attribution
  * 4389__NoiseCollector__pongblipF_3.wav
    * url: https://freesound.org/s/4389/
    * license: Attribution
  * 4388__NoiseCollector__pongblipE5.wav
    * url: https://freesound.org/s/4388/
    * license: Attribution
  * 4387__NoiseCollector__pongblipE4.wav
    * url: https://freesound.org/s/4387/
    * license: Attribution
  * 4386__NoiseCollector__pongblipE3.wav
    * url: https://freesound.org/s/4386/
    * license: Attribution
  * 4385__NoiseCollector__pongblipD5.wav
    * url: https://freesound.org/s/4385/
    * license: Attribution
  * 4384__NoiseCollector__pongblipD4.wav
    * url: https://freesound.org/s/4384/
    * license: Attribution
  * 4383__NoiseCollector__pongblipD3.wav
    * url: https://freesound.org/s/4383/
    * license: Attribution
  * 4382__NoiseCollector__pongblipD_5.wav
    * url: https://freesound.org/s/4382/
    * license: Attribution
  * 4381__NoiseCollector__pongblipD_4.wav
    * url: https://freesound.org/s/4381/
    * license: Attribution
  * 4380__NoiseCollector__pongblipD_3.wav
    * url: https://freesound.org/s/4380/
    * license: Attribution
  * 4379__NoiseCollector__pongblipG5.wav
    * url: https://freesound.org/s/4379/
    * license: Attribution
  * 4378__NoiseCollector__pongblipG4.wav
    * url: https://freesound.org/s/4378/
    * license: Attribution
  * 4377__NoiseCollector__pongblipG3.wav
    * url: https://freesound.org/s/4377/
    * license: Attribution
  * 4376__NoiseCollector__pongblipG_4.wav
    * url: https://freesound.org/s/4376/
    * license: Attribution
  * 4375__NoiseCollector__pongblipG_3.wav
    * url: https://freesound.org/s/4375/
    * license: Attribution
  * 4374__NoiseCollector__pongblipF5.wav
    * url: https://freesound.org/s/4374/
    * license: Attribution
  * 4373__NoiseCollector__pongblipF3.wav
    * url: https://freesound.org/s/4373/
    * license: Attribution
  * 4372__NoiseCollector__pongblipC5.wav
    * url: https://freesound.org/s/4372/
    * license: Attribution
  * 4371__NoiseCollector__pongblipC4.wav
    * url: https://freesound.org/s/4371/
    * license: Attribution
  * 4370__NoiseCollector__pongblipC_5.wav
    * url: https://freesound.org/s/4370/
    * license: Attribution
  * 4369__NoiseCollector__pongblipC_4.wav
    * url: https://freesound.org/s/4369/
    * license: Attribution
  * 4368__NoiseCollector__pongblipC_3.wav
    * url: https://freesound.org/s/4368/
    * license: Attribution
  * 4367__NoiseCollector__pongblipB4.wav
    * url: https://freesound.org/s/4367/
    * license: Attribution
  * 4366__NoiseCollector__pongblipB3.wav
    * url: https://freesound.org/s/4366/
    * license: Attribution
  * 4365__NoiseCollector__pongblipA5.wav
    * url: https://freesound.org/s/4365/
    * license: Attribution
  * 4364__NoiseCollector__pongblipA4.wav
    * url: https://freesound.org/s/4364/
    * license: Attribution
  * 4363__NoiseCollector__pongblipA3.wav
    * url: https://freesound.org/s/4363/
    * license: Attribution
  * 4362__NoiseCollector__pongblipA_4.wav
    * url: https://freesound.org/s/4362/
    * license: Attribution
  * 4361__NoiseCollector__pongblipA_3.wav
    * url: https://freesound.org/s/4361/
    * license: Attribution
  * 4360__NoiseCollector__ponblipG_5.wav
    * url: https://freesound.org/s/4360/
    * license: Attribution
  * 4359__NoiseCollector__PongBlipF4.wav
    * url: https://freesound.org/s/4359/
    * license: Attribution


